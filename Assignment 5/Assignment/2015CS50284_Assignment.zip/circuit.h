const int MAX_NETS = 10000;

int count=0;
int i,j,k;
int margin=50;
int check[2];
int name_count=0;
double scale_factor=1;
 FILE* out;


char * names[10000];

typedef struct
{
	char *name, *power, type;
	char * Net_Connected_to_terminal, * Net_Connected_to_other_terminal;
	double value;
	char *toprint;
}component;

typedef struct
{
	char *name,type;
	char * Net_Connected_to_terminal;
	char * Net_Connected_to_other_terminal;
	double dcoffset,amplitude,frequency,delay,damping;
	char * freq_power,* delay_power;
	char * sin_type;
	char *toprint[2];
}source;

typedef struct ns
{
	char *start,*end;
	component *c;
	source *s;
	struct ns *next;
}node;

node *nets[10000];

int checkUnitsComponent(char *q)
{
	if(strcmp(q,"O") && strcmp(q,"F") && strcmp(q,"H"))return 0;
	else return 1;
}

char setType(char *q)
{
	if(!strcmp(q,"O"))return 'R';
	else if(!strcmp(q,"F"))return 'C';
	else return 'L';
}

int checkNode(node n,int j)
{
	//printf("enetred checkNode with j: %d and count: %d\n",j,count);
	if(count==0)
	{
		/*names[name_count] = n.start;
		names[name_count+1] = n.end;
		name_count+=2;
		check[0]=0;
		check[1]=0;*/
		return -1;
	}
	//printf("nets[j]->start: %s and n.start: %s\n",nets[j].start,n.start);
	//printf("nets[j]->end: %s and n.end: %s\n",nets[j].end,n.end);
	if(j>=count)
	{
		/*printf("no\n");
		if(check[0]==0)
		{
			names[name_count]= n.start;
			name_count++;
		}
		if(check[1]==0)
		{
			names[name_count] = n.end;
			name_count++;
		}
		check[0]=0;
		check[1]=0;*/
		return -1;
	}
	else if(!strcmp(nets[j]->start,n.start) && !strcmp(nets[j]->end,n.end))			//eneters if strings are equal
	{
		return j;
	}
	else
	{
		//printf("nets: %s %s checked against: %s %s\n",nets[j].start,nets[j].end,n.start,n.end);
		//printf("being returned: %d\n",j);
		return checkNode(n,j+1);
	}
}

int abs(int x)
{
	if(x>0)return x;
	else return -x;
}

int isPresent(char *s)
{
	if(name_count==0)
	{
		names[0] = s;
		name_count=1;
		return 0;
	}
	else
	{
		for(int i=0;i<name_count;i++)
		{
			if(!strcmp(s,names[i]))return 1;
		}
	}
	names[name_count] = s;
	name_count++;
	return 0;
}

void add(node *n)
{
	//printf("count: %d\n",count);
	//printf("to be checked: %s %s\n",n.start, n.end);
	int a = isPresent(n->start);
	int b = isPresent(n->end);
	int x=-1;
	if(a && b)x = checkNode(*n,0);
	printf("%d\n", x);
	if(x==-1 && count<MAX_NETS-1)
	{
		nets[count]= n;
		count++;
	}
	else if(count==MAX_NETS-1)
	{
		printf("MAX_NETS exceeded");
	}
	else
	{
		printf("entering here with x: %d\n",x);
		n->next = nets[x];
		nets[x] = n;
		//printf("%s\n", nets[x]->s->name);
	}
}

void printdot(int x, int y)
{
	fprintf(out, "<circle cx = \"%d\" cy = \"%d\" r = \"2\" />\n", x, y);
}

void printLine(int x1, int y1 , int x2 , int y2)
{
	fprintf(out,"<line x1 = \"%d\" y1 = \"%d\" x2 = \"%d\" y2 = \"%d\" stroke=\"black\"/>\n",x1,y1,x2,y2);
}

void printInductor(component *c,int x,int y)
{
	fprintf(out,"<path fill=\"none\" stroke=\"black\" d=\"M %d,%d L %d,%d Q %d,%d %d,%d Q %d,%d %d,%d Q %d,%d %d,%d L %d,%d\"/>\n",x,y,x,y+10,x+10,y+15,x,y+20,x+10,y+25,x,y+30,x+10,y+35,x,y+40,x,y+50);
	fprintf(out,"</g>\n<text x=\"%d\" y=\"%d\" font-size=\"15\" fill=\"black\">%s %.3f %sH</text>\n<g transform=\"scale(%f)\">\n", (int)scale_factor*(x+10),(int)scale_factor*(y+25),c->name,c->value,c->toprint,scale_factor);
}

void printResistor(component *c,int x,int y)
{
	fprintf(out,"<path fill=\"none\" stroke=\"black\" d=\"M %d,%d L %d,%d L %d,%d %d,%d L %d,%d %d,%d L %d,%d %d,%d L %d,%d\"/>\n",x,y,x,y+10,x+10,y+15,x,y+20,x+10,y+25,x,y+30,x+10,y+35,x,y+40,x,y+50);
	fprintf(out,"</g>\n<text x=\"%d\" y=\"%d\" font-size=\"15\" fill=\"black\">%s %.3f %s</text>\n<g transform=\"scale(%f)\">\n", (int)scale_factor*(x+10),(int)scale_factor*(y+25),c->name,c->value,c->toprint,scale_factor);
}

void printCapacitor(component *c,int x, int y)
{
	fprintf(out,"<path fill=\"none\" stroke=\"black\" d=\"M %d,%d L %d,%d M %d,%d L %d,%d M %d,%d L %d,%d M %d,%d L %d,%d\"/>\n",x,y,x,y+20,x-8,y+20,x+8,y+20,x-8,y+30,x+8,y+30,x,y+30,x,y+50);
	fprintf(out,"</g>\n<text x=\"%d\" y=\"%d\" font-size=\"15\" fill=\"black\">%s %.3f %sF</text>\n<g transform=\"scale(%f)\">\n", (int)scale_factor*(x+10),(int)scale_factor*(y+25),c->name,c->value,c->toprint,scale_factor);
}

void printVoltage(source *s,int x1, int y1)
{
	int x= x1, y= y1+25;
	fprintf(out,"<circle fill=\"none\" stroke=\"black\" cx=\"%d\" cy=\"%d\" r=\"15\"/>\n<path fill=\"none\" stroke=\"black\" d=\"M %d,%d Q %d,%d %d,%d M %d,%d Q %d,%d %d,%d\"/>\n",x,y,x,y,x+5,y-10,x+10,y,x,y,x-5,y+10,x-10,y);
	fprintf(out,"</g>\n<text x=\"%d\" y=\"%d\" font-size=\"15\" fill=\"black\">%s (%.3f %.3f</text>\n", (int)scale_factor*(x+20),(int)scale_factor*(y),s->sin_type,s->dcoffset,s->amplitude);
	fprintf(out,"<text x=\"%d\" y=\"%d\" font-size=\"15\" fill=\"black\">%.3f%shz %.3f %.3f%s)</text>\n<g transform=\"scale(%f)\">\n", (int)scale_factor*(x+20),(int)scale_factor*(y+13),s->frequency,s->toprint[0],s->delay,s->damping,s->toprint[1],scale_factor);
	printLine(x1,y1,x1,y1+10);
	printLine(x1,y1+40,x1,y1+50);
}

void printCurrent(source *s,int x1, int y1)
{
	int x= x1, y= y1+25;
	fprintf(out,"<circle fill=\"none\" stroke=\"black\" cx=\"%d\" cy=\"%d\" r=\"15\"/>\n<path fill=\"none\" stroke=\"black\" d=\"M %d,%d L %d,%d L %d,%d L %d,%d L %d,%d\"/>\n",x,y,x1,y1+35,x,y1+15,x-2,y1+17,x+2,y1+17,x,y1+15);
fprintf(out,"</g>\n<text x=\"%d\" y=\"%d\" font-size=\"15\" fill=\"black\">%s (%.3f %.3f</text>\n", (int)scale_factor*(x+20),(int)scale_factor*(y),s->sin_type,s->dcoffset,s->amplitude);
	fprintf(out,"<text x=\"%d\" y=\"%d\" font-size=\"15\" fill=\"black\">%.3f%shz %.3f %.3f%s)</text>\n<g transform=\"scale(%f)\">\n", (int)scale_factor*(x+20),(int)scale_factor*(y+13),s->frequency,s->toprint[0],s->delay,s->damping,s->toprint[1],scale_factor);
	printLine(x1,y1,x1,y1+10);
	printLine(x1,y1+40,x1,y1+50);
}

void printmain(node n, int x, int y, int y2)
{	
	char type;
	if(n.s==NULL)type=n.c->type;
	else type=n.s->type;
	printf("printmain called with: %c %d %d %d",type,x,y,y2);
	printLine(x,y+50,x,y2);
	printdot(x,y2);
	printdot(x,y);
	if(type== 'R')
			printResistor(n.c,x, y);

	else if(type== 'L')
			printInductor(n.c,x, y);

	else if(type=='C')
			printCapacitor(n.c,x, y);

	else if(type== 'V')
			printVoltage(n.s,x, y);
		
	else if(type== 'I')
			printCurrent(n.s,x, y);
}

void printtext(int x, int y, char* s)
{
	fprintf(out, "<text x=\"%d\" y=\"%d\" font-size=\"15\" fill=\"black\">%s</text>", (int)scale_factor*x, (int)scale_factor*y, s );
}

void printnames()
{
	int i;
	fprintf(out,"</g>");
	for (i = 0; i < name_count; i++)
	{
		printtext(margin-10*strlen(names[i]),i*50+margin,names[i]);
	}
	fprintf(out,"<g transform=\"scale(%f)\">",scale_factor);
}

int getNum(char *s)
{
	int i=0;
	for(i=0;i<name_count;i++)
	{
		if(!strcmp(s,names[i]))return i;
	}
	printf("could not find the net");
	return -1;
}

void fnc()
{
	int i=0;
	out = fopen("output.svg","w");
	fprintf(out, "<svg xmlns=\"http://www.w3.org/2000/svg\" height=\"10000\" width=\"10000\">\n<g transform=\"scale(%f)\">\n",scale_factor);
	int sizes[name_count];
	for(i=0;i<name_count;i++)sizes[i]=margin;
	//printf("yes: %d\n",count);
	for(i=0;i<count;i++)
	{
		int r=0;
		node *n;
		n=nets[i];

		while(n!=NULL)
		{
			int x = getNum(n->start);
			int y = getNum(n->end);

			printf("num of %s is: %d\n",n->start,x);
			printf("num of %s is: %d\n",n->end,y);

			if(x==-1 || y==-1)
			{
				printf("Net was not found. returned from fnc\n");
				return;
			}

			int z=abs(x-y);
			int max,min;
			if(x>y){max=x;min=y;}
			else {max=y;min=x;}

			printf("sizes[%d]: %d\n",min,sizes[min]);
			printf("sizes[%d]: %d\n",max,sizes[max]);

			printf("yes: %d\n",i);
			/*if(z==1)
			{
				printf("yes!!!!");
				printLine(20,min*50+20,r*50+20,min*50+20);
				printmain(*n,r*50+20,min*50+20,max*50+20);
				printLine(20,max*50+20,r*50+20,max*50+20);
				for(j=0;j<max;j++)
				{
					sizes[j]+=100;
				}
				r++;
			}
			else
			{*/
				if(z==1 && r==0)
				{
					printmain(*n,margin,min*50+margin,max*50+margin);
					r++;
				}
				else
				{
					int max_size;
					if(sizes[min]>sizes[max])max_size=sizes[min];
					else max_size= sizes[max];
					printLine(margin,min*50+margin,max_size+100,min*50+margin);
					printLine(margin,max*50+margin,max_size+100,max*50+margin);
					printmain(*n,max_size+100,min*50+margin,max*50+margin);
					for(j=min;j<max;j++)
					{
						sizes[j]=max_size+100;
					}
				}
				
			n=n->next;
		}
		
	}
	printnames();
	fprintf(out, "%s\n", "</g>\n</svg>");
}


void printAllNode()
{
	printf("count: %d\n",count);
	int j=0;
	if(count==0)printf("No node added\n");
	else 
		{
			for(j=0;j<count;j++)
			{
				if(nets[j]->c!=NULL)
				{
					printf("nets%d: %s\n",j,nets[j]->c->name);
					if(nets[j]->next!=NULL)printf("nrts%d: %s\n",j,nets[j]->next->c->name);
				}
				else
				{
					printf("nets%d: %s\n",j,nets[j]->s->name);
				}
			}
		}

	for(j=0;j<name_count;j++)
	{
		printf("name%d: %s\n",j,names[j]);
	}
}